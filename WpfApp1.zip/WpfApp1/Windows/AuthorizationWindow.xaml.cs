﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1.Windows
{
    /// <summary>
    /// Логика взаимодействия для AuthorizationWindow.xaml
    /// </summary>
    public partial class AuthorizationWindow : Window
    {
        public AuthorizationWindow()
        {
            InitializeComponent();
        }
        Entities.PP_02Entities db;
        int q = 0;
        CaptchaWindow captchawindow = new CaptchaWindow();
        private void Authorization_Click(object sender, RoutedEventArgs e)
        {
            q++;

            db = new Entities.PP_02Entities();
            if (login.Text != "" && login.Text != " " && password.Text != "" && password.Text != " ")
            {
                if (db.Employees.Any(x => x.login == login.Text && x.password == password.Text))
                {
                    var user = db.Employees.FirstOrDefault(x => x.login == login.Text && x.password == password.Text);
                    try
                    {
                        var functionId = db.Functions.Where(x => x.id == user.function_id).FirstOrDefault();
                        user.last_time_input = DateTime.Now;
                        user.input_type_id = 1;
                        db.SaveChanges();
                        switch (functionId.title)
                        {
                            case "Продавец":
                                SalesmanWindow salesman = new SalesmanWindow();
                                this.Close();
                                salesman.Show();
                                break;
                            case "Старший смены":
                                SalesmanWindow salesman1= new SalesmanWindow();
                                this.Close();
                                salesman1.Show();
                                break;
                            case "Администратор":
                                AdministratorWindow administrator = new AdministratorWindow();
                                this.Close();
                                administrator.Show();
                                break;
                        }
                    }
                    catch { MessageBox.Show("Ошибка входа");user.input_type_id = 2; db.SaveChanges(); } 
                }
                else
                {
                    MessageBox.Show("Такого пользователя не существует");
                    if (q >= 3)
                    { CaptchaWindow captchawindow = new CaptchaWindow(); captchawindow.ShowDialog(); q = 0; }
                }
            }
            else { MessageBox.Show("Введите логин и пароль"); }
        }
        private void passwordHide_Click(object sender, RoutedEventArgs e)
        {
            if (passwordHide.IsChecked == true)
            {
                passwordBox.Visibility = Visibility.Visible;
                password.Visibility = Visibility.Hidden;
                passwordBox.Password = password.Text;
            }
            if (passwordHide.IsChecked == false)
            {
                password.Visibility = Visibility.Visible;
                passwordBox.Visibility = Visibility.Hidden;
                password.Text = passwordBox.Password;
            }
        }
    }
}
