﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1.Windows
{
    /// <summary>
    /// Логика взаимодействия для CaptchaWindow.xaml
    /// </summary>
    public partial class CaptchaWindow : Window
    {
        public CaptchaWindow()
        {
            InitializeComponent();
            GenerateCaptcha();
        }

        private Random random = new Random();
        string text = "";
        int q = 0;
        private void GenerateCaptcha()
        {
            text = "";
            // Генерация случайного текста для капчи
            string stringArray = "q.w.e.r.t.y.u.i.o.p.a.s.d.f.g.h.j.k.l.z.x.c.v.b.n.m.Q.W.E.R.T.Y.U.I.O.P.A.S.D.F.G.H.J.K.L.Z.X.C.V.B.N.M.1.2.3.4.5.6.7.8.9.0";
            string[] strings = stringArray.Split('.');
            for (int i = 0; i < 4; i++)
            {
                text = text + strings[random.Next(0, 61)];
            }
            // Создание DrawingVisual для визуализации текста
            DrawingVisual drawingVisual = new DrawingVisual();
            using (DrawingContext drawingContext = drawingVisual.RenderOpen())
            {
                // Заполнение фона капчи
                SolidColorBrush backgroundBrush = new SolidColorBrush(Colors.LightGray);
                drawingContext.DrawRectangle(backgroundBrush, null, new Rect(0, 0, 200, 50));
                // Добавление шума внутри текста
                for (int i = 0; i < 2000; i++)
                {
                    SolidColorBrush noiseBrush = new SolidColorBrush(GenerateRandomColor());
                    double x = random.Next(200);
                    double y = random.Next(50);
                    double size = random.Next(1, 4);
                    Ellipse ellipse = new Ellipse()
                    {
                        Fill = noiseBrush,
                        Width = size,
                        Height = size
                    };
                    drawingContext.DrawEllipse(noiseBrush, null, new Point(x, y), size, size);
                }
                // Добавление текста капчи
                FormattedText formattedText = new FormattedText(text, System.Globalization.CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                                                                new Typeface("Curlz MT"), 40, Brushes.Black);
                Point textPosition = new Point(random.Next(120), random.Next(-10,0));
                drawingContext.DrawText(formattedText, textPosition);
            }
            // Создание VisualBrush для отображения капчи в TextBlock
            VisualBrush visualBrush = new VisualBrush(drawingVisual);
            txtblock.Background = visualBrush;
        }
        private Color GenerateRandomColor()
        {
            // Реализация логики генерации случайного цвета для шума
            byte r = (byte)random.Next(256);
            byte g = (byte)random.Next(256);
            byte b = (byte)random.Next(256);
            return Color.FromRgb(r, g, b);
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            q++;
            //Проверка на верность капчи
            if (text == txtbox.Text)
            { q = 0; this.Close(); }
            else
            {
                MessageBox.Show("Капча введена неверно");
                if (q >= 3)
                {
                    //Блокировка кнопки ввода
                    button.IsEnabled = false;
                    Generate.IsEnabled = false;
                    txtbox.IsEnabled = false;
                    Task.Delay(10000).ContinueWith(_ =>
                    {
                        Dispatcher.Invoke(() => {
                            button.IsEnabled = true; Generate.IsEnabled = true;
                            txtbox.IsEnabled = true;
                        });
                    });
                }
            }
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //повторная генерация капчи
            GenerateCaptcha();
        }
    }
}
