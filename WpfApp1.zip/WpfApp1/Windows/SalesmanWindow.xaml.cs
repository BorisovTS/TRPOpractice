﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Entities;

namespace WpfApp1.Windows
{
    /// <summary>
    /// Логика взаимодействия для SalesmanWindow.xaml
    /// </summary>
    public partial class SalesmanWindow : Window
    {
        Entities.PP_02Entities db = new Entities.PP_02Entities();
        public SalesmanWindow()
        {
            InitializeComponent();
            refresh();
        }

        private void addOrderBtn_Click(object sender, RoutedEventArgs e)
        {
            AddOrderWindow orderWindow = new AddOrderWindow();
            orderWindow.ShowDialog();
            refresh();
        }

        private void addServiceBtn_Click(object sender, RoutedEventArgs e)
        {
            if (OrderListView.SelectedItem != null)
            {
                try
                {
                    int id_order = ((Order)OrderListView.SelectedItem).id;
                    var date = db.Orders.Where(x => x.id == id_order).FirstOrDefault();
                    Order order = new Order
                    {
                        code = date.code,
                        order_date = date.order_date,
                        order_time = date.order_time,
                        client_id = date.client_id,
                        service_id = ServiceCmbBox.SelectedIndex + 1,
                        status_id = date.status_id,
                        close_date = date.close_date,
                        time_period = date.time_period,
                    };
                    db.Orders.Add(order);
                    db.SaveChanges();
                    refresh();
            }
                catch (Exception ex)
                {
                MessageBox.Show("Выберите услугу и заказ, который хотите дополнить: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); e.Handled = true;
            }
        }              
        }

        private void addClientBtn_Click(object sender, RoutedEventArgs e)
        {
            AddClientWindow clientWindow = new AddClientWindow();
            clientWindow.ShowDialog();
            refresh();
        }
        public void refresh()
        {
            PP_02Entities entities = new PP_02Entities();
            List<Order> Orders  = entities.Orders.ToList();
            OrderListView.ItemsSource = Orders;
            List<Service> Services = entities.Services.ToList();
            ServiceListView.ItemsSource = Services;
            List<Client> Clients = entities.Clients.ToList();
            ClientListView.ItemsSource = Clients;
            var services = db.Services.Select(item => item.title).ToList();
            foreach (var service in services)
            {
                ServiceCmbBox.Items.Add(service);
            }
        } 
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            AuthorizationWindow authorizationWindow = new AuthorizationWindow();
            authorizationWindow.Show();
            this.Close();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            if (OrderListView.SelectedItem != null)
            {
                try
                {
                    int id_order = ((Order)OrderListView.SelectedItem).id;
                    var date = db.Orders.Where(x => x.id == id_order).FirstOrDefault();
                    date.close_date = DateTime.Now;
                    date.status_id = 3;
                    db.SaveChanges();
                    refresh();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Выберите заказ, который хотите закрыть" + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); e.Handled = true;
                }
            }                
        }

        private void findClient_TextChanged(object sender, TextChangedEventArgs e)
        {
            List<Client> clients = db.Clients.ToList();
            if (findClient.Text.Length > 0)
            {
                var _find = db.Clients.Where(x => x.surname.ToLower().Contains(findClient.Text.ToLower())).ToArray();
                clients = _find.ToList();
                ClientListView.ItemsSource = clients;
            }
            if (findClient.Text.Length == 0)
            {
                List<Client> Clients = db.Clients.ToList();
                ClientListView.ItemsSource = Clients;
            }
        }
        private void findService_TextChanged(object sender, TextChangedEventArgs e)
        {
            List<Service> services = db.Services.ToList();
            if (findService.Text.Length > 0)
            {
                var _find = db.Services.Where(x => x.title.ToLower().Contains(findService.Text.ToLower())).ToArray();
                services = _find.ToList();
                ServiceListView.ItemsSource = services;
            }
            if (findService.Text.Length == 0)
            {
                List<Service> Services = db.Services.ToList();
                ServiceListView.ItemsSource = Services;
            }
        }
    }
}
