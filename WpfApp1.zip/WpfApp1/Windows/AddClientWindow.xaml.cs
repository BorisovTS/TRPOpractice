﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1.Windows
{
    /// <summary>
    /// Логика взаимодействия для AddClientWindow.xaml
    /// </summary>
    public partial class AddClientWindow : Window
    {
        Entities.PP_02Entities db = new Entities.PP_02Entities();
        public AddClientWindow()
        {
            InitializeComponent();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (db.Clients.Any(x => x.email != email.Text) && db.Clients.Any(x => x.password != password.Text))
                {
                    Entities.Client client = new Entities.Client
                    {
                        firstname = firstname.Text,
                        surname = surname.Text,
                        patronymic = patronymic.Text,
                        code = code.Text,
                        series = series.Text,
                        number = number.Text,
                        born_date = Convert.ToDateTime(born_date.Text),
                        address = address.Text,
                        email = email.Text,
                        password = password.Text,
                    };
                    db.Clients.Add(client);
                    db.SaveChanges();
                    this.Close();
                }
                else { MessageBox.Show("Такой клиент уже существует"); }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Проверьте корректность данных ", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); e.Handled = true;
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
