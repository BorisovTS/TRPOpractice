﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1.Windows
{
    /// <summary>
    /// Логика взаимодействия для AddOrderWindow.xaml
    /// </summary>
    public partial class AddOrderWindow : Window
    {
        Entities.PP_02Entities db = new Entities.PP_02Entities();
        public AddOrderWindow()
        {
            InitializeComponent();
            var services = db.Services.Select(item => item.title).ToList();
            foreach (var service in services)
            {
                serviceCmbBox.Items.Add(service);
            }
            var clients = db.Clients.Select(item => item.email).ToList();
            foreach (var client in clients)
            {
                clientCmbBox.Items.Add(client);
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (db.Orders.Any(x => x.order_date != DateTime.Today) && db.Orders.Any(x => x.client_id != clientCmbBox.SelectedIndex+1))
                {
                    var service = db.Services.Where(x => x.title == serviceCmbBox.Text).FirstOrDefault();
                    var client = db.Clients.Where(x => x.email == clientCmbBox.Text).FirstOrDefault();
                    Entities.Order order = new Entities.Order
                    {
                        code = client.code+"/"+DateTime.Today.ToString("dd-MM-yyyy"),
                        order_date = DateTime.Today,
                        order_time = DateTime.Now.TimeOfDay,
                        client_id = clientCmbBox.SelectedIndex+1,
                        service_id = serviceCmbBox.SelectedIndex+1,
                        status_id = 2,
                        close_date = null,
                        time_period = Convert.ToInt32(time_period.Text),
                    };
                    db.Orders.Add(order);
                    db.SaveChanges();
                    this.Close();
                }
                else { MessageBox.Show("Такой заказ уже существует"); }
        }
            catch (Exception ex)
            {
                MessageBox.Show("Проверьте корректность данных ", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); e.Handled = true;
            }
}

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
