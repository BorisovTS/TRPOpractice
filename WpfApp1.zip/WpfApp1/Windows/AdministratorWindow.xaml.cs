﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Entities;

namespace WpfApp1.Windows
{
    /// <summary>
    /// Логика взаимодействия для AdministratorWindow.xaml
    /// </summary>
    public partial class AdministratorWindow : Window
    {
        Entities.PP_02Entities db = new Entities.PP_02Entities();
        public AdministratorWindow()
        {
            InitializeComponent();
            refresh();
            var functions = db.Functions.Select(item => item.title).ToList();
            foreach (string function  in functions)
            {
                FilterCmbBox.Items.Add(function);
            }         
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            AuthorizationWindow authorizationWindow = new AuthorizationWindow();
            authorizationWindow.Show();
            this.Close();
        }

        private void FilterCmbBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (FilterCmbBox.SelectedIndex == 0)
            {
                refresh();
            }
            if (FilterCmbBox.SelectedIndex >= 1)
            {
                var function = db.Functions.Where(x=>x.id == FilterCmbBox.SelectedIndex).FirstOrDefault();
                var employees = db.Employees.Where(x=>x.function_id == function.id).ToList();
                EmployeeListView.ItemsSource = employees;
            }
        }
        public void refresh()
        {
            PP_02Entities entities = new PP_02Entities();
            List<Order> Orders = entities.Orders.ToList();
            OrderListView.ItemsSource = Orders;
            List<Employee> Employees = entities.Employees.ToList();
            EmployeeListView.ItemsSource = Employees;            
        }
    }
}
